// Auto-recarga: el actualizador externo reemplaza los archivos de esta carpeta.
// Cada minuto la extensión lee su propio manifest.json desde disco y, si la versión
// cambió respecto a la que tiene cargada, se recarga sola para aplicar los cambios.
const LOADED_VERSION = chrome.runtime.getManifest().version;

async function checkForNewVersionOnDisk() {
  try {
    const url = chrome.runtime.getURL("manifest.json") + "?t=" + Date.now();
    const res = await fetch(url, { cache: "no-store" });
    const onDisk = await res.json();
    if (onDisk && onDisk.version && onDisk.version !== LOADED_VERSION) {
      chrome.runtime.reload();
    }
  } catch (e) {
    // archivo en medio de una actualización: se reintenta en el siguiente ciclo
  }
}

chrome.alarms.get("check-disk", (alarm) => {
  if (!alarm) chrome.alarms.create("check-disk", { periodInMinutes: 1 });
});
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "check-disk") checkForNewVersionOnDisk();
});
chrome.runtime.onStartup.addListener(checkForNewVersionOnDisk);
chrome.runtime.onInstalled.addListener(checkForNewVersionOnDisk);
